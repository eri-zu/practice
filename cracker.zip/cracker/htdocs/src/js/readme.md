## 各ファイル説明

menu.ejsとかあげる  
トップ以外もあげる  

```
├── BALANCeLibs
│   ├── Util
│   │   ├── 省略
│   └── View
│       └── 省略
├── Conf.es6
├── Main.es6
├── Model
│   ├── Resource
│   │   ├── 省略
│   └── Url
│       ├── 省略
├── Util
│   ├── Array.es6
│   ├── Controller.es6
│   ├── Ease.es6
│   ├── Easing
│   │   └── index.es6
│   └── Math
│       └── index.es6
├── View
│   ├── Controller.es6
│   └── UI
│       ├── Common
│       │   ├── Loading：ローディングの処理
│       │   │   ├── Controller.es6
│       │   │   ├── Events.es6
│       │   │   └── Render.es6
│       │   ├── Opening：オープニングの処理
│       │   │   └── Controller.es6
│       │   └── Transition：遷移アニメーションの処理
│       │       └── Controller.es6
│       ├── Controller.es6
│       └── Pages：各ページの処理
│           └── Controller.es6
└── readme.md
```
