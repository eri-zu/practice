//--------------------------------------------------
//
//  LoadMgr
//
//--------------------------------------------------

// import {Promise} from 'es6-promise';

import O from './OtherLoader.js';
import Loader from './THREELoader.js';

export default class LoadMgr {

  constructor() {

    this.isFirst = true;

    this.setup();
    // this.setEvents();
      
  }

  setup() {
   
  }

  setupLoad() {


   
  }

  setEvents() {


  }

}